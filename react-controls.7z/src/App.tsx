import "./App.css";
import { Button, Input } from "./components";

const onClick = (event: React.MouseEvent<HTMLButtonElement>) => {
  console.log(event);
};

function App() {
  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-3">
          <Button
            text="Click me"
            customClassNames="btn-primary"
            onClick={onClick}
          />
        </div>
        <div className="col-3">
          <Button
            text="Click me"
            customClassNames="btn-secondary"
            onClick={onClick}
          />
        </div>
        <div className="col-3">
          <Button
            text="Click me"
            customClassNames="btn-danger"
            onClick={onClick}
          />
        </div>
        <div className="col-3">
          <Button
            text="Click me"
            customClassNames="btn-success"
            onClick={onClick}
            customStyle={{ borderRadius: "50px", width: "100%" }}
            disabled={true}
          />
        </div>
      </div>

      <div className="row mt-5">
        <div className="col-6">
          <Input
            id="input1"
            label="Input 1"
            customStyle={{ borderRadius: "25px" }}
          />
        </div>
      </div>
    </div>
  );
}

export default App;
