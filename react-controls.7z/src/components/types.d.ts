import React, { ButtonHTMLAttributes, InputHTMLAttributes, ReactElement }from "react";

export interface GeneralProps {
    customClassNames?: string;
    customStyle?: React.CSSProperties;
    children?: ReactElement;
    disabled?: boolean;
}

export interface ButtonProps extends GeneralProps{
    text: string;
    onClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
    type?: ButtonHTMLAttributes<HTMLButtonElement>["type"];
}

export interface InputProps extends GeneralProps{
    label: string;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    value?: string;
    onKeyPress?: (event: React.KeyboardEvent<HTMLInputElement>) => void;
    onblur?: (event: React.FocusEvent<HTMLInputElement>) => void;
    isValid?: boolean = true;
    successMessage?: string;
    errorMessage?: string;
    readOnly?: boolean;
    regex?: RegExp;
    id: string;
}