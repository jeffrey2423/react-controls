import {FunctionComponent} from 'react';
import { InputProps } from '../types';

export const Input:FunctionComponent<InputProps> = (props: InputProps) => {
  return (
    <div className="form-floating">
        <input 
            type="text" 
            className={`form-control ${props?.customClassNames ?? ''} ${props?.isValid === false ? 'is-invalid' : ''}`}
            id={props.id}
            placeholder={props.label}
            style={props?.customStyle ?? {}}
        />
        <label 
            htmlFor={props.id}
            style={{color: 'gray'}}
        >
            {props.label}
        </label>
    </div>
  )
}