import {FunctionComponent} from 'react';
import { ButtonProps } from '../types';

export const Button:FunctionComponent<ButtonProps> = (props: ButtonProps) => {
  return (
    <button
        className={`btn ${props?.customClassNames ?? ''}`}
        style={props?.customStyle ?? {}}
        onClick={props?.onClick}
        disabled={props?.disabled}
        type={props?.type ?? 'button'}
    >
        {props.text}
        {props?.children ?? <></>}
    </button>
  )
}